from django import forms
from sites.models import post

class HomeForm(forms.ModelForm):
    post = forms .URLField(widget = forms.TextInput(
        attrs = {
            'class': 'form-control',
            'placeholder': 'Your URL...'
            
        }
    ))

    class Meta:
        model = post
        fields = ('post',)