from __future__ import unicode_literals
from django.views.generic import TemplateView
from django.shortcuts import render
from sites.forms import HomeForm
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from lxml import html
import sys
import requests
from bs4 import BeautifulSoup as bs
from datetime import datetime
from urlparse import urlparse
import re
from sites.models import Sites,data_store
import ast
import urllib2
#from django.db import model


def extractor(text):       
        result = {'Global':'0','country':'na','countrystatus':''}
        domain_to_query=text
       
        url = "http://www.alexa.com/siteinfo/" + domain_to_query
        page = requests.get(url).text
        soup = bs(page)

        for span in soup.find_all('span'):
            if span.has_attr("class"):
                if "globleRank" in span["class"]:
                    for strong in span.find_all("strong"):
                        if strong.has_attr("class"):
                            if "metrics-data" in strong["class"]:
                                result['Global'] = strong.text
        # Extracting CountryRank
                if "countryRank" in span["class"]:
                    image = span.find_all("img")
                    for img in image:
                        if img.has_attr("title"):
                            country = img["title"].replace(" Flag", "")
                    for strong in span.find_all("strong"):
                        if strong.has_attr("class"):
                            if "metrics-data" in strong["class"]:
                                result['country'] = strong.text
        result['countrystatus']=result['country']
        if result['country']=="na":
            result['country']='10000000'  
            result['countrystatus']="Not Available"    
        return result


def norton_report(text):
    result ={'Computer_Threats':''}
    domain_to_query=text
    url = "https://safeweb.norton.com/report/show?url=" + domain_to_query
    page = requests.get(url).text
    soup = bs(page)
    for div1 in soup.find_all('div',class_='span10'):
        result['Computer_Threats']=div1.text
    
    return result
    
    


def who_is_extractor(text):       
        result = {'Domain':'','Register':'','Registration_Date':'','Expiration_Date':'','Updated_Date':''}
        domain_to_query=text
        url = "https://www.whois.com/whois/" + domain_to_query
        page = requests.get(url).text
        soup = bs(page)
        count=0
        count2=1
        for div1 in soup.find_all('div',class_='df-block'):
            if(count==0):
                for div2 in soup.find_all('div',class_='df-row'):
                    for div3 in soup.find_all('div',class_='df-value'):
                        if(count2==1):
                            result['Domain'] = div3.text
                        elif(count2==2):
                            result['Register']=div3.text
                        elif(count2==3):
                            result['Registration_Date']=div3.text
                        elif(count2==4):
                            result['Expiration_Date']=div3.text
                        elif(count2==5):
                            result['Updated_Date']=div3.text
                        count2=count2+1
                count=1
            else:
                break
        return result


def find(args):
    rank=args['Global']
    l=len(args['Global'])
    val=0
    i=0
    score=0
    url=str(args['text'])
    age_sts=check_age(args)
    life_sts=check_life(args)
    check_domain_result =check_domain_extension(args)
    args['domain_sts']=check_domain_result
    score = score+url_length(url)
    score = score+check__url(str(args['domain']))
    score = score+check_forward_slash(url)
    score = score+check_At_sign(url)
    score = score+check_dots(url)
    score = score+link_score(args)
    score = score+url_certi(url)
    
    args['countrymsg']="No need..." 
    args['globalmsg']="No comment..."
    for i in rank:
        if i >='0' and i <='9':
            val = val * 10 + int(i)
    if(val==0):
        score = score+3
    elif(val<50000):
        score = score+20
    elif(val<200000):
        score = score+17
    elif(val<500000):
        score = score+15
    elif(val<1500000):
        score = score+13
    elif(val<3500000):
        score = score+10
    else:
        score=score+7

    args['score']=score                           
    
    if(val<500000 and val>0):
        args['globalmsg']="Safe if global rank is below 5,00,000"
        return "This Site is safe"
    countryRank=args['country']
    l=len(countryRank)
    val=0
    i=0
    #args['countrymsg']=countryRank
    for i in countryRank:
        if i >='0' and i <='9':
            val = val * 10 + int(i) 
    if(val<25000 and val!=0):
        args['countrymsg']="safe if country rank is below 25000"
        #args['countrymsg']=val  
        return "This Site is safe" 
   
    if(age_sts==1):
        return "This Site is safe"
    temp =0    
    if args['days']:
        temp = int(args['days'])
    if(check_domain_result==1):
        return "This Site is safe"
    if(life_sts==1 and temp>=200):
        return "This Site is safe"
    if(score>67):
        return "This Site is safe"
    return "This Site may be harmful"   
def link_score(args):
    count1 = args['internal_link_count']
    count2 = args['external_link_count']
    total = count1+count2
    score=0
    if total!=0:
        score = (count2*100)/total
        if score <=20:
            args['ext_result']="Ratio of external links is very less. good for a authentic website"
            return 20
        if score<=40:

            args['ext_result']="Ratio of external links is less. ok ok for a authentic website"
            return 15
        if score<=65:
            args['ext_result']="Ratio of external links is little  high. It might be harmful..."
            return 11
        if score<=75:
            args['ext_result']="Ratio of external links is very high. Be careful it might harm you." 
            return 9
        if score==100 and count2>=5:
            args['ext_result']="Ratio of external links is very high. Be careful it might harm you." 
            return 4
        args['ext_result']="Ratio of external links is very high. Be careful it might harm you."    
        return 7
    else:
        args['ext_result']="-"    
        return 17

def link_count(text,domain):
    result ={'internal_link_count':'','external_link_count':'','internal_link':'','external_link':'',}
    page = requests.get(text).text
    soup = bs(page)
    count1 = 0
    count2=0
    internal_link=[]
    external_link=[]

    temp = ''
    count=0
    #x = domain[8:12]
    if(domain[7:11].find('www.')!=-1 or domain[8:12].find('www.')!=-1):
        if domain[4]=='s':
            domain = domain[12:]
        else:
            domain = domain[11:]
    else:
        if domain[4]=='s':
            domain = domain[8:]
        else:
            domain = domain[7:]
    for link in soup.findAll("a",href=True):
        temp =str(link.get("href"))
        if temp!='#' and temp!='':
            if(temp[0]=='.' or temp[0]=='/' or(temp!='' and temp.find(domain)!=-1)):
                count1 = count1+1
                internal_link.append(temp)
                
            else:
                count2 = count2+1
                external_link.append(temp) 

    for link in soup.findAll("link",href=True):
        temp =str(link.get("href"))
        if temp!='#':
            if(temp[0]=='.' or temp[0]=='/' or (temp!='' and temp.find(domain)!=-1)):
                count1 = count1+1
                internal_link.append(temp)
            else:
                count2 = count2+1
                external_link.append(temp)
            
    
    result['internal_link_count']=count1
    result['external_link_count']=count2
    result['internal_link']=internal_link
    result['external_link']=external_link
    return result




def url_length(url):
    len1 = len(url)
    if(len1<=54):
        return 10
    elif(len<=65):
        return 6
    else:
        return 4
def check__url(url):
    sub_string = '-'
    count = count_substring(url,sub_string)
    if(count<=1):
        return 10
    elif(count>=2 and count<=5):
        return 7
    else:
        return 5

def check_forward_slash(url):
    sub_string = '//'
    count = count_substring(url,sub_string)
    if(count>1):
        return 4
    else:
        return 10
def check_dots(url):
    sub_string = '.'
    count = count_substring(url,sub_string)
    if(count<=3):
        return 10
    if(count<=5):
        return 8
    elif(count>5 and count<=10):
        return 7
    else:
        return 5
def check_At_sign(url):
    sub_string = '@'
    count = count_substring(url,sub_string)
    if(count>1):
        return 4
    else:
        return 10

def count_substring(string,sub_string):
    count = string.count(sub_string)
    return count

def check_age(args):
    rdate = str(args['Registration_Date'])
    days=str_to_date(rdate)
    args['days'] = days
    #args['days'] =len(rdate)
    if days>=540:
        return 1
    else:
        return 0

def check_life(args):
    edate = str(args['Expiration_Date'])
    days=str_to_date(edate)
    args['rdays'] = days
    if days>=540:
        return 1
    else:
        return 0

def str_to_date(rdate):
    now  = datetime.now()
    tyear = int(now.year)
    tmonth = int(now.month)
    tday  = int(now.day)
    if len(rdate)==10:
        ryear = int(rdate[0])*1000+int(rdate[1])*100+int(rdate[2])*10+int(rdate[3])
        rmonth = int(rdate[5])*10+int(rdate[6])
        rday = int(rdate[8])*10+int(rdate[9])
        days = (abs(tyear-ryear)*365)+(abs(tmonth-rmonth)*30)+abs(tday-rday)
        return days

"""def url_analyze(args):
    url = args['text']
    certi_no=url_certi(args)"""
def url_certi(url):
    if url[4]=='s':
        return 10
    else:
         return 6
    

def check_domain_extension(args):
    url = args['text']
    domain =['gov.in','mil.in','edu.in','nic.in','ac.in','res.in']
    for i in domain:
        if(url.find(i)!=-1):
            return 1
    return 0



class HomeView(TemplateView):
    template_name = 'sites/home.html'
    def get(self,request):
        form = HomeForm()
        args = {
            'form': form,
            'show': '0',
        }
        return render(request,self.template_name,args)
    def post(self,request):
        form = HomeForm(request.POST)
        if form.is_valid():
            post = form.save(commit = False)
            post.save()
            text = form.cleaned_data['post']
            url = text
            
            try:
                obj = data_store.objects.get(your_url=str(url))
            except data_store.DoesNotExist:
                obj = None
            
            if(obj!=None):
                args = {
                'show':'1',
                'form':form,
                'text':obj.your_url,
                'Global':obj.globel_rank,
                'cn':obj.country_rank,
                #'cn':result['countrystatus'],
                'Domain':obj.domain,
                'Register':obj.register,
                'Registration_Date':obj.register_date,
                'Expiration_Date':obj.expiration_date,
                'Updated_Date':obj.updated_date,
                'Computer_Threats':obj. norten_report,
                'result':obj.result,
                'domain_sts':obj.domain_extension_sts,
                'domain':obj.domain2,
                'score':obj.score,
                'internal_link_count':obj.internal_links_count,
                'external_link_count':obj.external_links_count,
                'countrymsg':obj.country_rank_msg,
                'ext_result':obj.external_link_msg,
                'globalmsg':obj.globel_rank_msg,
                'external_link':(ast.literal_eval(str(obj.external_links))),
                'internal_link':(ast.literal_eval(str(obj.internal_links))),
                }
                return render(request,self.template_name,args)

            """sitesobj='None'
            try:
                sitesobj = Sites.objects.get(website=str(url))
            except Sites.DoesNotExist:
                sitesobj = None
            try:
                autho_sites = Sites.objects.all()
            except Sites.DoesNotExist:
                autho_sites = None
            if (sitesobj!=None):
                args={'show':'2','result':'This Site is safe','form':form,'autho_sites':autho_sites,}
                return render(request,self.template_name,args)"""
            try:
                urllib2.urlopen(text)
            except urllib2.HTTPError, e:
                args={'page_not_found':e.code,'form':form}
                return render(request,self.template_name,args)
            except urllib2.URLError, e:
                args={'page_not_found':e.args,'form':form}
                return render(request,self.template_name,args)
    
            result=extractor(text)
            whois_result=who_is_extractor(text)
            norton_report_result=norton_report(text)
            parsed_uri = urlparse( text )
            #link_result = link_count(text,domain)
            domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
            link_result = link_count(text,domain)
            text=domain
            args = {'show':'1','form':form,'text':url,
            'Global':result['Global'],'country':result['country'],'cn':result['countrystatus'],
            'Domain':whois_result['Domain'],'Register':whois_result['Register'],
            'Registration_Date':whois_result['Registration_Date'],
            'Expiration_Date':whois_result['Expiration_Date'],
            'Updated_Date':whois_result['Updated_Date'],
            'Computer_Threats':norton_report_result['Computer_Threats'],'result':'',
            'days':'','rdays':'','domain_sts':'','domain':domain,'url_length':'','score':'',
            'internal_link':link_result['internal_link'],
            'external_link':link_result['external_link'],
            'internal_link_count':link_result['internal_link_count'],
            'external_link_count':link_result['external_link_count'],
            }
            #args['countrymsg']=countrymsg(args)
            check=find(args)
            args['result']=check
            args['show']='1'
            obj = data_store()
            obj.your_url=args['text']
            obj.country_rank=args['cn']
            obj.globel_rank=args['Global']
            obj.domain=args['Domain']
            obj.register=args['Register']
            obj.register_date=args['Registration_Date']
            obj.expiration_date=args['Expiration_Date']
            obj.updated_date=args['Updated_Date']
            obj.domain_extension_sts=args['domain_sts']
            obj.score=str(args['score'])
            obj.internal_links_count=str(args['internal_link_count'])
            obj.external_links_count=str(args['external_link_count'])
            obj.result=args['result']
            obj.domain2=args['domain']
            obj. norten_report=args['Computer_Threats']
            obj.country_rank_msg=args['countrymsg']
            obj.globel_rank_msg=args['globalmsg']
            obj.external_link_msg=args['ext_result']
            obj.external_links = args['external_link']
            obj.internal_links = args['internal_link']
            obj.save()
            return render(request,self.template_name,args)

        else:
            args={'page_not_found':'Enter valid URL3','form':form}
            return render(request,self.template_name,args)

    