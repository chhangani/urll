# -*- coding: utf-8 -*-
from __future__ import unicode_literals


from django.db import models
class post(models.Model):
    post = models.CharField(max_length=500)
    def __str__(self):
        return self.post


class Sites(models.Model):
    website = models.URLField(max_length=100,default =' ')
    def __str__(self):
        return self.website


class data_store(models.Model):
    your_url=models.URLField(max_length=200,primary_key=True)
    country_rank=models.CharField(max_length=20,default=' ')
    globel_rank=models.CharField(max_length=20,default=' ')
    domain=models.CharField(max_length=40,default=' ')
    register=models.CharField(max_length=40,default=' ')
    register_date=models.CharField(max_length=40,default=' ')
    expiration_date=models.CharField(max_length=40,default=' ')
    updated_date=models.CharField(max_length=40,default=' ')
    domain_extension_sts=models.CharField(max_length=40,default=' ')
    score=models.CharField(max_length=5,default='0')
    internal_links_count=models.CharField(max_length=5,default='0')
    external_links_count=models.CharField(max_length=5,default='0')
    result=models.CharField(max_length=50,default=' ')
    domain2=models.CharField(max_length=40,default=' ')
    norten_report=models.CharField(max_length=200,default=' ')
    country_rank_msg=models.CharField(max_length=100,default=' ')
    external_link_msg=models.CharField(max_length=100,default=' ')
    globel_rank_msg=models.CharField(max_length=100,default=' ')
    internal_links = models.TextField(default=' ')
    external_links = models.TextField(default=' ')
    def __str__(self):
        return self.your_url