# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import Sites,post,data_store
# Register your models here.
admin.site.site_header = "Admin"
admin.site.register(Sites)
admin.site.register(post)
admin.site.register(data_store)



   